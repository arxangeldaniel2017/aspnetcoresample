﻿using System;
using System.Collections.Generic;



namespace aspnetapp.Model
{
    public class DtmUserGroup
    {
        public decimal UserGroupId { get; set; }
        public string UserGroupName { get; set; }
        public string UserGroupDescription { get; set; }
    }
}
