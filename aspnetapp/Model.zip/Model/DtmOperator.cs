﻿using System;
using System.Collections.Generic;



namespace aspnetapp.Model
{
    public class DtmOperator
    {
        public decimal OperatorId { get; set; }
        public string OperatorName { get; set; }
        public string OperatorValue { get; set; }
    }
}
