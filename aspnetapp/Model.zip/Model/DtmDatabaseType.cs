﻿using System;
using System.Collections.Generic;



namespace aspnetapp.Model
{
    public class DtmDatabaseType
    {
        public decimal DatabaseTypeId { get; set; }
        public string DatabaseTypeName { get; set; }
    }
}
