﻿using System;
using System.Collections.Generic;



namespace aspnetapp.Model
{
    public class DtmUploadType
    {
        public decimal UploadTypeId { get; set; }
        public string UploadTypeName { get; set; }
    }
}
