﻿using System;
using System.Collections.Generic;



namespace aspnetapp.Model
{
    public class DtmApplicationXmlObject
    {
        public int ApplicationXmlObjectsId { get; set; }
        public int ApplicationXmlObjectsApplicationId { get; set; }
        public int ApplicationXmlObjectsXmlObjectId { get; set; }
        public int ApplicationXmlObjectsHtmlTableCellId { get; set; }
    }
}
