﻿using System;
using System.Collections.Generic;



namespace aspnetapp.Model
{
    public class DtmParameterType
    {
        public decimal ParameterTypeId { get; set; }
        public string ParameterTypeName { get; set; }
    }
}
