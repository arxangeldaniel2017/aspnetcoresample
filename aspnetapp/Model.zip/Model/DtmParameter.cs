﻿using System;
using System.Collections.Generic;



namespace aspnetapp.Model
{
    public class DtmParameter
    {
        public decimal ParameterId { get; set; }
        public string ParameterName { get; set; }
        public decimal ParameterSiteId { get; set; }
        public decimal ParameterParameterTypeId { get; set; }
        //public object ParameterDefaultValue { get; set; }
    }
}
