﻿using System;
using System.Collections.Generic;



namespace aspnetapp.Model
{
    public class DtmUserGroupsUser
    {
        public decimal UserGroupsUsersId { get; set; }
        public decimal UserGroupsUsersUserGroupId { get; set; }
        public decimal UserGroupsUsersUserId { get; set; }
    }
}
