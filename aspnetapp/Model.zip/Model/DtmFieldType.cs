﻿using System;
using System.Collections.Generic;



namespace aspnetapp.Model
{
    public class DtmFieldType
    {
        public decimal FieldTypeId { get; set; }
        public string FieldTypeName { get; set; }
    }
}
