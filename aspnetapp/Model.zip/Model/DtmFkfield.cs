﻿using System;
using System.Collections.Generic;



namespace aspnetapp.Model
{
    public class DtmFkfield
    {
        public decimal FkfieldId { get; set; }
        public decimal FkfieldTableId { get; set; }
        public decimal FkfieldKeyFieldId { get; set; }
    }
}
