﻿using System;
using System.Collections.Generic;



namespace aspnetapp.Model
{
    public class DtmFilterParameter
    {
        public decimal FilterParametersId { get; set; }
        public decimal FilterParametersFilterId { get; set; }
        public decimal FilterParametersParameterId { get; set; }
    }
}
