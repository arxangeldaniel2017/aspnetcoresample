﻿using System;
using System.Collections.Generic;



namespace aspnetapp.Model
{
    public class DtmApplication
    {
        public decimal Id { get; set; }
        public decimal ApplicationSiteId { get; set; }
        public string ApplicationName { get; set; }
        public string ApplicationCaption { get; set; }
    }
}
