﻿using System;
using System.Collections.Generic;



namespace aspnetapp.Model
{
    public class DtmHtmlTableRow
    {
        public decimal HtmlTableRowId { get; set; }
        public decimal HtmlTableRowHtmlTableId { get; set; }
        public string HtmlTableRowPropertiesString { get; set; }
        public int? HtmlTableRowRowspan { get; set; }
        public int HtmlTableRowOrderBy { get; set; }
    }
}
