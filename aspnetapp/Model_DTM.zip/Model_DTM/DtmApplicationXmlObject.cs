﻿using System;
using System.Collections.Generic;

#nullable disable

namespace aspnetapp.Model_DTM
{
    public partial class DtmApplicationXmlObject
    {
        public decimal ApplicationXmlObjectsId { get; set; }
        public decimal ApplicationXmlObjectsApplicationId { get; set; }
        public decimal ApplicationXmlObjectsXmlObjectId { get; set; }
        public decimal ApplicationXmlObjectsHtmlTableCellId { get; set; }
    }
}
