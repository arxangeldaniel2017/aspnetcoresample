﻿using System;
using System.Collections.Generic;

#nullable disable

namespace aspnetapp.Model_DTM
{
    public partial class DtmOperator
    {
        public decimal OperatorId { get; set; }
        public string OperatorName { get; set; }
        public string OperatorValue { get; set; }
    }
}
