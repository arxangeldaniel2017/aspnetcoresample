﻿using System;
using System.Collections.Generic;

#nullable disable

namespace aspnetapp.Model_DTM
{
    public partial class DtmFilterParameter
    {
        public decimal FilterParametersId { get; set; }
        public decimal FilterParametersFilterId { get; set; }
        public decimal FilterParametersParameterId { get; set; }
    }
}
