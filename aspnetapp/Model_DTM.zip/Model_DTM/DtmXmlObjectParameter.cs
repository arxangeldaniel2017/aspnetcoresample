﻿using System;
using System.Collections.Generic;

#nullable disable

namespace aspnetapp.Model_DTM
{
    public partial class DtmXmlObjectParameter
    {
        public decimal XmlObjectParametersId { get; set; }
        public decimal XmlObjectParametersXmlObjectId { get; set; }
        public decimal XmlObjectParametersParameterId { get; set; }
    }
}
