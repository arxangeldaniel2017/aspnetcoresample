﻿using System;
using System.Collections.Generic;

#nullable disable

namespace aspnetapp.Model_DTM
{
    public partial class DtmParameterType
    {
        public decimal ParameterTypeId { get; set; }
        public string ParameterTypeName { get; set; }
    }
}
