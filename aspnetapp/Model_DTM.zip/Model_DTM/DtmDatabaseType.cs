﻿using System;
using System.Collections.Generic;

#nullable disable

namespace aspnetapp.Model_DTM
{
    public partial class DtmDatabaseType
    {
        public decimal DatabaseTypeId { get; set; }
        public string DatabaseTypeName { get; set; }
    }
}
