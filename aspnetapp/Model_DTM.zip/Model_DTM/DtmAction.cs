﻿using System;
using System.Collections.Generic;

#nullable disable

namespace aspnetapp.Model_DTM
{
    public partial class DtmAction
    {
        public decimal ActionId { get; set; }
        public string ActionName { get; set; }
    }
}
