﻿using System;
using System.Collections.Generic;

#nullable disable

namespace aspnetapp.Model_DTM
{
    public partial class DtmFkfield
    {
        public decimal FkfieldId { get; set; }
        public decimal FkfieldTableId { get; set; }
        public decimal FkfieldKeyFieldId { get; set; }
    }
}
