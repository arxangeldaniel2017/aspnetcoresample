﻿using System;
using System.Collections.Generic;

#nullable disable

namespace aspnetapp.Model_DTM
{
    public partial class DtmUserGroup
    {
        public decimal UserGroupId { get; set; }
        public string UserGroupName { get; set; }
        public string UserGroupDescription { get; set; }
    }
}
