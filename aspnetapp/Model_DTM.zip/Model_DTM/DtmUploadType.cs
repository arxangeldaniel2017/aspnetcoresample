﻿using System;
using System.Collections.Generic;

#nullable disable

namespace aspnetapp.Model_DTM
{
    public partial class DtmUploadType
    {
        public decimal UploadTypeId { get; set; }
        public string UploadTypeName { get; set; }
    }
}
