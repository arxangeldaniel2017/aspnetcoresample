﻿using System;
using System.Collections.Generic;

#nullable disable

namespace aspnetapp.Model_DTM
{
    public partial class DtmFieldType
    {
        public decimal FieldTypeId { get; set; }
        public string FieldTypeName { get; set; }
    }
}
