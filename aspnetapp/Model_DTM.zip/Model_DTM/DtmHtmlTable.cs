﻿using System;
using System.Collections.Generic;

#nullable disable

namespace aspnetapp.Model_DTM
{
    public partial class DtmHtmlTable
    {
        public decimal HtmlTableId { get; set; }
        public string HtmlTableName { get; set; }
        public string HtmlTablePropertiesString { get; set; }
        public int HtmlTableOrderBy { get; set; }
    }
}
