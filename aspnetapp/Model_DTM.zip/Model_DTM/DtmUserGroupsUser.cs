﻿using System;
using System.Collections.Generic;

#nullable disable

namespace aspnetapp.Model_DTM
{
    public partial class DtmUserGroupsUser
    {
        public decimal UserGroupsUsersId { get; set; }
        public decimal UserGroupsUsersUserGroupId { get; set; }
        public decimal UserGroupsUsersUserId { get; set; }
    }
}
